#!/usr/bin/env python3
"""
C++ Time Complexity Analyzer - GUI Application

A Python GUI program that loads .cpp files and analyzes the time complexity
(Big-O notation) of each function in the source code.

Uses only the Python standard library (tkinter for GUI, re for parsing).
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from dataclasses import dataclass, field
from enum import Enum
import re
import os

# ═══════════════════════════════════════════════════════════════════════════════
# Data Classes
# ═══════════════════════════════════════════════════════════════════════════════


class Confidence(Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


@dataclass
class LoopInfo:
    """Represents a detected loop in the code."""
    start_line: int
    end_line: int
    nesting_level: int = 0       # 0 = outermost loop
    is_logarithmic: bool = False  # counter *= 2, counter /= 2, etc.
    loop_type: str = "for"       # 'for', 'while', 'do-while', 'range-for'
    body_start: int = 0          # char position inside function body (start)
    body_end: int = 0            # char position inside function body (end)


@dataclass
class STLCall:
    """Represents an STL algorithm call with known complexity."""
    name: str                    # e.g., 'std::sort'
    complexity: str              # e.g., 'O(n log n)'
    line: int
    body_pos: int = 0            # character position inside function body


@dataclass
class RecursionInfo:
    """Information about recursion in a function."""
    is_recursive: bool = False
    is_mutual_recursive: bool = False
    calls_self: bool = False
    callee_names: list[str] = field(default_factory=list)
    # Estimated recurrence pattern
    recurrence_type: str = ""    # 'divide_by_2', 'subtract_1', 'branch', 'unknown'
    divisor: int = 1             # input size divisor per call (2 for T(n/2))
    branches: int = 1            # number of recursive calls per invocation


@dataclass
class FunctionInfo:
    """Represents a parsed C++ function."""
    name: str
    start_line: int
    end_line: int
    return_type: str
    parameters: str
    body: str                    # code between outermost { }
    signature: str               # full function signature
    loops: list[LoopInfo] = field(default_factory=list)
    max_loop_depth: int = 0
    recursion: RecursionInfo = field(default_factory=RecursionInfo)
    stl_calls: list[STLCall] = field(default_factory=list)


@dataclass
class ComplexityResult:
    """The analyzed time complexity of a function."""
    function_name: str
    big_o: str                   # e.g., "O(n²)", "O(log n)"
    reasoning: str               # human-readable explanation
    confidence: Confidence = Confidence.MEDIUM


# ═══════════════════════════════════════════════════════════════════════════════
# C++ Parser
# ═══════════════════════════════════════════════════════════════════════════════

class CppParser:
    """Parses C++ source code to extract function definitions and control structures."""

    # Keywords that can precede a '(' but are NOT function definitions
    NON_FUNCTION_KEYWORDS = {
        'if', 'else', 'while', 'for', 'do', 'switch', 'case', 'return',
        'catch', 'throw', 'new', 'delete', 'sizeof', 'typeof', 'decltype',
        'static_cast', 'dynamic_cast', 'const_cast', 'reinterpret_cast',
        'class', 'struct', 'enum', 'union', 'namespace', 'using', 'typedef',
        'template', 'typename', 'explicit', 'friend', 'virtual', 'inline',
        'noexcept', 'alignof', 'alignas', 'constexpr', 'consteval',
        'auto', 'public', 'private', 'protected',
    }

    # Constructor/destructor patterns
    CONSTRUCTOR_PATTERN = re.compile(
        r'(?:explicit|inline|virtual)?\s*([~\w][\w:]*(?:::[~\w][\w:]*)?)\s*\(([^)]*)\)\s*'
        r'(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?(?:final\s*)?'
        r'(?::\s*[^{;]*?)?\s*\{'
    )

    # Function definition regex — matches return_type function_name (params) { ... }
    FUNCTION_REGEX = re.compile(
        r'(?:^|\n)\s*'                           # start of line
        r'((?:[\w:]+(?:<[^>]*>)?[\s*&]+)+)'     # return type (possibly templated)
        r'([~\w:]+(?:<[^>]*>)?)\s*'             # function name (possibly qualified)
        r'\(([^)]*)\)\s*'                        # parameters
        r'(const\s*)?'                           # optional const qualifier
        r'(?:noexcept\s*)?'                      # optional noexcept
        r'(?:override\s*)?'                      # optional override
        r'(?:final\s*)?'                         # optional final
        r'(?::\s*[^{;]*?)?'                      # optional initializer list
        r'\s*\{',                                 # opening brace
        re.MULTILINE
    )

    # Loop detection patterns
    FOR_LOOP_RE = re.compile(r'\bfor\s*\(.*?\)\s*\{?', re.DOTALL)
    WHILE_LOOP_RE = re.compile(r'\bwhile\s*\(.*?\)\s*\{?')
    DO_WHILE_RE = re.compile(r'\bdo\s*\{')
    RANGE_FOR_RE = re.compile(r'\bfor\s*\([^;:]*:[^;]*\)\s*\{?')

    # Logarithmic loop patterns
    LOG_MULTIPLY_RE = re.compile(r'(\w+)\s*\*=\s*\d+')
    LOG_DIVIDE_RE = re.compile(r'(\w+)\s*/=\s*\d+')
    LOG_FOR_MULT = re.compile(r'for\s*\([^;]*;[^;]*;\s*\w+\s*\*=\s*\d+\s*\)')
    LOG_FOR_DIV = re.compile(r'for\s*\([^;]*;[^;]*;\s*\w+\s*/=\s*\d+\s*\)')

    # Binary search / divide-conquer pattern
    BINARY_SEARCH_PATTERN = re.compile(
        r'(?:mid|middle|pivot)\s*=\s*\(\s*\w+\s*\+\s*\w+\s*\)\s*/\s*2'
    )

    # Recursive call detection
    CALL_RE = re.compile(r'\b(\w+(?:::\w+)?)\s*\(')

    # STL algorithm patterns mapped to their complexities
    STL_COMPLEXITIES = {
        'std::sort':                'O(n log n)',
        'std::stable_sort':         'O(n log n)',
        'std::partial_sort':        'O(n log k)',
        'std::nth_element':         'O(n)',
        'std::binary_search':       'O(log n)',
        'std::lower_bound':         'O(log n)',
        'std::upper_bound':         'O(log n)',
        'std::equal_range':         'O(log n)',
        'std::find':                'O(n)',
        'std::find_if':             'O(n)',
        'std::count':               'O(n)',
        'std::count_if':            'O(n)',
        'std::search':              'O(n*m)',
        'std::reverse':             'O(n)',
        'std::rotate':              'O(n)',
        'std::unique':              'O(n)',
        'std::remove':              'O(n)',
        'std::remove_if':           'O(n)',
        'std::min_element':         'O(n)',
        'std::max_element':         'O(n)',
        'std::minmax_element':      'O(n)',
        'std::next_permutation':    'O(n)',
        'std::prev_permutation':    'O(n)',
        'std::push_heap':           'O(log n)',
        'std::pop_heap':            'O(log n)',
        'std::make_heap':           'O(n)',
        'std::sort_heap':           'O(n log n)',
        'std::is_heap':             'O(n)',
        'std::merge':               'O(n)',
        'std::inplace_merge':       'O(n log n)',
        'std::set_union':           'O(n)',
        'std::set_intersection':    'O(n)',
        'std::set_difference':      'O(n)',
        'std::all_of':              'O(n)',
        'std::any_of':              'O(n)',
        'std::none_of':             'O(n)',
        'std::for_each':            'O(n)',
        'std::copy':                'O(n)',
        'std::copy_if':             'O(n)',
        'std::fill':                'O(n)',
        'std::generate':            'O(n)',
        'std::replace':             'O(n)',
        'std::replace_if':          'O(n)',
        'std::transform':           'O(n)',
        'std::swap_ranges':         'O(n)',
        'std::adjacent_find':       'O(n)',
        'std::equal':               'O(n)',
        'std::mismatch':            'O(n)',
        'std::partition':           'O(n)',
        'std::stable_partition':    'O(n)',
        'std::is_partitioned':      'O(n)',
        'std::is_sorted':           'O(n)',
        'std::is_sorted_until':     'O(n)',
        # NOTE: bare 'sort'/'qsort'/'bsearch' omitted — they would also match
        # inside 'std::sort' etc. due to \b boundary between :: and the name.
    }

    def __init__(self):
        self._lines: list[str] = []
        self._all_function_names: list[str] = []

    def parse(self, source_code: str) -> list[FunctionInfo]:
        """Main entry point: parse C++ source into structured FunctionInfo objects."""
        self._lines = source_code.split('\n')

        # 1. Pre-process: strip comments, string literals, preprocessor directives
        clean_code = self._preprocess(source_code)

        # 2. Find function definitions
        functions = self._find_functions(clean_code, source_code)

        # 3. Store all function names for recursion detection
        self._all_function_names = [f.name for f in functions]

        # 4. For each function, analyze its body
        for func in functions:
            self._analyze_function_body(func, clean_code)

        # 5. Detect recursion (self + mutual)
        self._detect_recursion(functions)

        return functions

    # ── Pre-processing ──────────────────────────────────────────────────────

    def _preprocess(self, code: str) -> str:
        """Strip comments, string/char literals, and preprocessor lines."""
        # Strip block comments /* ... */
        code = re.sub(r'/\*.*?\*/', ' ', code, flags=re.DOTALL)
        # Strip line comments //
        code = re.sub(r'//[^\n]*', ' ', code)
        # Strip string literals (both "..." and raw R"(...)" )
        code = re.sub(r'R"([^(]*)\(.*?\)\1"', '" "', code, flags=re.DOTALL)
        code = re.sub(r'"(?:\\.|[^"\\])*"', '" "', code)
        # Strip char literals
        code = re.sub(r"'(?:\\.|[^'\\])*'", "' '", code)
        # Strip preprocessor lines (but keep newlines to preserve line counts)
        code = re.sub(r'^\s*#.*$', '', code, flags=re.MULTILINE)
        return code

    # ── Function Detection ──────────────────────────────────────────────────

    def _find_functions(self, clean_code: str, original_code: str) -> list[FunctionInfo]:
        """Locate all function definitions using regex + brace matching."""
        functions = []
        pos = 0

        while pos < len(clean_code):
            match = self.FUNCTION_REGEX.search(clean_code, pos)
            if not match:
                break

            return_type = match.group(1).strip()
            func_name = match.group(2).strip()
            params = match.group(3).strip()

            # Filter out non-function keywords as return types
            base_name = func_name.split('::')[-1] if '::' in func_name else func_name
            if base_name in self.NON_FUNCTION_KEYWORDS:
                pos = match.start() + 1
                continue

            # Filter out control-flow keywords used as "function names"
            # e.g., "if (...)" should not match
            if return_type.strip() in self.NON_FUNCTION_KEYWORDS:
                # But "void", "int", etc. are fine
                if return_type.strip() in {'if', 'else', 'while', 'for', 'do', 'switch',
                                             'return', 'catch', 'throw', 'class', 'struct'}:
                    pos = match.start() + 1
                    continue

            # Find the opening brace position in the clean code
            brace_pos = match.end() - 1  # position of '{'
            open_brace_col = self._position_to_line_col(clean_code, brace_pos)

            # Find matching closing brace
            end_pos = self._find_matching_brace(clean_code, brace_pos)
            if end_pos == -1:
                pos = match.end()
                continue

            body = clean_code[brace_pos + 1:end_pos]

            # Get original line numbers
            start_line = self._position_to_line(clean_code, match.start())
            end_line = self._position_to_line(clean_code, end_pos)

            # Extract original signature from the original code
            signature = self._extract_signature(original_code, match, clean_code)

            functions.append(FunctionInfo(
                name=base_name,
                start_line=start_line,
                end_line=end_line,
                return_type=return_type,
                parameters=params,
                body=body,
                signature=signature,
            ))

            pos = end_pos + 1

        return functions

    def _extract_signature(self, original_code: str, match: re.Match, clean_code: str) -> str:
        """Extract the function signature from the original (unprocessed) code."""
        # Approximate: take everything from the match start to the opening brace
        match_start_in_clean = match.start()
        brace_open = match.end() - 1

        # Convert positions: find the corresponding range in original code
        # We'll approximate by using line numbers
        start_line = self._position_to_line(clean_code, match_start_in_clean)
        end_line = self._position_to_line(clean_code, brace_open)
        original_lines = original_code.split('\n')
        if 0 <= start_line <= end_line < len(original_lines):
            return '\n'.join(original_lines[start_line:end_line + 1])
        return f"{match.group(1)} {match.group(2)}({match.group(3)})"

    # ── Brace Matching ──────────────────────────────────────────────────────

    def _find_matching_brace(self, code: str, open_pos: int) -> int:
        """Find the matching closing brace for an opening brace at open_pos."""
        if open_pos >= len(code) or code[open_pos] != '{':
            return -1
        depth = 0
        i = open_pos
        while i < len(code):
            ch = code[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return i
            i += 1
        return -1

    def _find_opening_brace(self, code: str, keyword_pos: int) -> int:
        """Find the opening '{' near a keyword (for/while/do) position."""
        i = keyword_pos
        while i < len(code):
            if code[i] == '{':
                return i
            if code[i] == ';':  # single-statement body without braces
                return -1
            i += 1
        return -1

    # ── Position Helpers ────────────────────────────────────────────────────

    def _position_to_line(self, code: str, pos: int) -> int:
        """Convert a character position in code to a 0-based line number."""
        return code[:pos].count('\n')

    def _position_to_line_col(self, code: str, pos: int) -> tuple[int, int]:
        """Convert a character position to (line, column) 0-based."""
        line = code[:pos].count('\n')
        last_nl = code[:pos].rfind('\n')
        col = pos - (last_nl + 1) if last_nl != -1 else pos
        return line, col

    # ── Body Analysis: Loops ────────────────────────────────────────────────

    def _analyze_function_body(self, func: FunctionInfo, clean_code: str) -> None:
        """Parse a function body for loops, recursion hints, and STL calls."""
        body = func.body
        func.loops = self._detect_loops(body, func.start_line, clean_code)
        func.stl_calls = self._detect_stl_calls(body, func.start_line)

        # Calculate max loop nesting depth
        if func.loops:
            func.max_loop_depth = max(loop.nesting_level for loop in func.loops)
        else:
            func.max_loop_depth = 0

    def _find_matching_paren(self, code: str, open_pos: int) -> int:
        """Find the matching closing paren for an opening paren at open_pos."""
        if open_pos >= len(code) or code[open_pos] != '(':
            return -1
        depth = 0
        i = open_pos
        while i < len(code):
            ch = code[i]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    return i
            i += 1
        return -1

    def _find_brace_after(self, code: str, pos: int) -> int:
        """Find the first opening brace '{' after pos, stopping at ';' (single-stmt loop)."""
        i = pos
        while i < len(code):
            if code[i] == '{':
                return i
            if code[i] == ';':
                return -1  # single-statement loop without braces
            i += 1
        return -1

    def _detect_loops(self, body: str, func_start_line: int, full_clean_code: str) -> list[LoopInfo]:
        """Detect all loops in a function body with nesting tracking.

        Uses paren-matching (not regex) to correctly handle for/while headers
        that contain nested parentheses like ``arr.size()``.
        """
        loops: list[LoopInfo] = []
        # (start_char_pos, end_char_pos, type, is_log) — all in body-relative positions
        all_loop_starts: list[tuple[int, int, str, bool]] = []

        # ── 'for' loops ─────────────────────────────────────────────────
        for match in re.finditer(r'\bfor\s*\(', body):
            paren_open = match.end() - 1  # position of '(' after 'for'
            paren_close = self._find_matching_paren(body, paren_open)
            if paren_close == -1:
                continue

            header = body[paren_open + 1:paren_close]

            # Find the opening brace after the closing paren
            open_brace = self._find_brace_after(body, paren_close)
            if open_brace == -1:
                continue  # single-statement for without braces — skip

            end_pos = self._find_matching_brace(body, open_brace)
            if end_pos == -1:
                continue

            # Check logarithmic patterns in the for header
            is_log = bool(re.search(r'\w+\s*\*=\s*\d+', header) or
                          re.search(r'\w+\s*/=\s*\d+', header))

            loop_type = 'range-for' if (':' in header and ';' not in header) else 'for'
            all_loop_starts.append((match.start(), end_pos, loop_type, is_log))

        # ── 'while' loops ────────────────────────────────────────────────
        for match in re.finditer(r'\bwhile\s*\(', body):
            paren_open = match.end() - 1
            paren_close = self._find_matching_paren(body, paren_open)
            if paren_close == -1:
                continue

            open_brace = self._find_brace_after(body, paren_close)
            if open_brace == -1:
                continue

            end_pos = self._find_matching_brace(body, open_brace)
            if end_pos == -1:
                continue

            all_loop_starts.append((match.start(), end_pos, 'while', False))

        # ── 'do … while' loops ───────────────────────────────────────────
        for match in re.finditer(r'\bdo\s*\{', body):
            open_brace = match.end() - 1  # position of '{'
            end_pos = self._find_matching_brace(body, open_brace)
            if end_pos == -1:
                continue
            all_loop_starts.append((match.start(), end_pos, 'do-while', False))

        # Sort by start position
        all_loop_starts.sort(key=lambda x: x[0])

        # Calculate nesting using a stack of (char_end, info)
        stack: list[tuple[int, LoopInfo]] = []

        for start, end, loop_type, is_log in all_loop_starts:
            # Pop loops whose bodies end before this one starts
            while stack and stack[-1][0] <= start:
                stack.pop()

            nesting = len(stack)

            # Check the loop *body* for logarithmic patterns
            if not is_log:
                loop_body = body[start:end]
                if (self.LOG_MULTIPLY_RE.search(loop_body) or
                        self.LOG_DIVIDE_RE.search(loop_body)):
                    is_log = True
                if self.BINARY_SEARCH_PATTERN.search(loop_body):
                    is_log = True

            start_line_abs = func_start_line + body[:start].count('\n')
            end_line_abs = func_start_line + body[:end].count('\n')

            loop_info = LoopInfo(
                start_line=start_line_abs,
                end_line=end_line_abs,
                nesting_level=nesting,
                is_logarithmic=is_log,
                loop_type=loop_type,
                body_start=start,
                body_end=end,
            )
            loops.append(loop_info)
            stack.append((end, loop_info))

        return loops

    # ── STL Detection ───────────────────────────────────────────────────────

    def _detect_stl_calls(self, body: str, func_start_line: int) -> list[STLCall]:
        """Detect STL algorithm calls in the function body."""
        stl_calls = []
        for stl_name, complexity in self.STL_COMPLEXITIES.items():
            pattern = re.compile(r'\b' + re.escape(stl_name) + r'\s*\(')
            for match in pattern.finditer(body):
                line_offset = body[:match.start()].count('\n')
                stl_calls.append(STLCall(
                    name=stl_name,
                    complexity=complexity,
                    line=func_start_line + line_offset,
                    body_pos=match.start(),
                ))
        return stl_calls

    # ── Recursion Detection ─────────────────────────────────────────────────

    def _detect_recursion(self, functions: list[FunctionInfo]) -> None:
        """Detect direct and mutual recursion among parsed functions."""
        name_to_func = {f.name: f for f in functions}

        for func in functions:
            # Find all function calls in the body
            calls = self.CALL_RE.findall(func.body)
            # Filter to actual function names we know about
            known_calls = set()
            for call in calls:
                base = call.split('::')[-1] if '::' in call else call
                if base in name_to_func:
                    known_calls.add(base)

            func.recursion.callee_names = list(known_calls)
            func.recursion.calls_self = func.name in known_calls
            func.recursion.is_recursive = func.recursion.calls_self

            if func.recursion.calls_self:
                func.recursion = self._analyze_recursion_pattern(func)

        # Mutual recursion detection
        for func in functions:
            if func.recursion.is_recursive:
                continue
            for callee_name in func.recursion.callee_names:
                callee = name_to_func.get(callee_name)
                if callee and callee.recursion.callee_names and func.name in callee.recursion.callee_names:
                    func.recursion.is_recursive = True
                    func.recursion.is_mutual_recursive = True
                    func.recursion.recurrence_type = 'mutual'
                    break

    def _analyze_recursion_pattern(self, func: FunctionInfo) -> RecursionInfo:
        """Analyze the recurrence pattern of a recursive function."""
        info = func.recursion
        body = func.body

        # Count self-calls
        self_call_pattern = re.compile(r'\b' + re.escape(func.name) + r'\s*\(')
        self_calls = self_call_pattern.findall(body)
        info.branches = len(self_calls)

        # Try to determine the reduction factor
        # Look for patterns like func(n/2), func(n-1), func(l, m), func(m+1, r)

        # Pattern: argument divided by 2 or constant
        # e.g., mergeSort(arr, l, m); mergeSort(arr, m+1, r);
        #       binarySearch(arr, mid+1, r);
        divide_pattern = re.compile(
            r'\b' + re.escape(func.name) + r'\s*\([^)]*[/+]\s*\d+[^)]*\)'
        )
        subtract_pattern = re.compile(
            r'\b' + re.escape(func.name) + r'\s*\([^)]*[-]\s*\d+[^)]*\)'
        )
        half_pattern = re.compile(
            r'\b' + re.escape(func.name) + r'\s*\([^)]*/\s*2[^)]*\)'
        )

        if half_pattern.search(body):
            info.recurrence_type = 'divide_by_2'
            info.divisor = 2
        elif divide_pattern.search(body):
            info.recurrence_type = 'divide'
            info.divisor = 2
        elif subtract_pattern.search(body):
            info.recurrence_type = 'subtract_1'
            info.divisor = 1
        elif info.branches >= 2:
            info.recurrence_type = 'branch'
        elif info.branches == 1:
            info.recurrence_type = 'single'
        else:
            info.recurrence_type = 'unknown'

        return info


# ═══════════════════════════════════════════════════════════════════════════════
# Complexity Analyzer
# ═══════════════════════════════════════════════════════════════════════════════

class ComplexityAnalyzer:
    """Computes Big-O time complexity from parsed FunctionInfo objects."""

    # Complexity order for comparison (higher index = more complex)
    COMPLEXITY_ORDER = [
        'O(1)', 'O(log n)', 'O(log² n)', 'O(sqrt n)',
        'O(n)', 'O(n log n)', 'O(n log² n)',
        'O(n²)', 'O(n² log n)', 'O(n³)',
        'O(2ⁿ)', 'O(n!)', 'Unknown',
    ]

    def __init__(self):
        self._complexity_index = {c: i for i, c in enumerate(self.COMPLEXITY_ORDER)}

    def analyze(self, func: FunctionInfo) -> ComplexityResult:
        """Analyze a single function and return its complexity."""
        complexities: list[tuple[str, str]] = []  # (complexity, reason)

        # 1. Check recursion
        recursion_result = self._analyze_recursion(func)
        if recursion_result:
            complexities.append(recursion_result)

        # 2. Check loops (incorporates STL calls that fall inside loop bodies)
        loop_result = self._analyze_loops(func)
        if loop_result:
            complexities.append(loop_result)

        # 3. Check STL calls that are NOT inside loops (sequential → max)
        stl_inside_loop = set()
        for loop in func.loops:
            for stl in func.stl_calls:
                if loop.body_start <= stl.body_pos <= loop.body_end:
                    stl_inside_loop.add(stl.name)

        for stl in func.stl_calls:
            if stl.name not in stl_inside_loop:
                complexities.append(
                    (stl.complexity,
                     f'Calls {stl.name} (complexity: {stl.complexity}) — not inside a loop'))

        # 4. If nothing detected, it's O(1)
        if not complexities:
            return ComplexityResult(
                function_name=func.name,
                big_o='O(1)',
                reasoning='No loops, no recursion, no significant STL calls — constant time.',
                confidence=Confidence.HIGH,
            )

        # 5. Combine: sequential takes max
        final_complexity, final_reason = self._combine_complexities(complexities)

        # Determine confidence
        confidence = self._determine_confidence(func, complexities)

        return ComplexityResult(
            function_name=func.name,
            big_o=final_complexity,
            reasoning=final_reason,
            confidence=confidence,
        )

    # ── Loop Analysis ───────────────────────────────────────────────────────

    # Complexity ranks for common Big-O classes (used for max() comparisons)
    _RANK = {
        'O(1)': 0, 'O(log n)': 1, 'O(n)': 2, 'O(n log n)': 3,
        'O(n²)': 4, 'O(n² log n)': 5, 'O(n³)': 6, 'O(2ⁿ)': 7, 'O(n!)': 8,
    }

    @staticmethod
    def _stl_n_factor(complexity: str) -> int:
        """Return how many linear 'n' dimensions an STL call contributes."""
        if 'n²' in complexity or 'n^2' in complexity:
            return 2
        # "O(n log n)", "O(n)", "O(n*m)" all contain a linear-n factor.
        # "O(log n)" and "O(1)" and "O(2ⁿ)" do NOT contribute linear n.
        if complexity in ('O(log n)', 'O(log² n)', 'O(1)', 'O(2ⁿ)', 'O(n!)'):
            return 0
        if 'n' in complexity:
            return 1
        return 0

    @staticmethod
    def _stl_log_factor(complexity: str) -> int:
        """Return how many 'log n' factors an STL call contributes."""
        if 'log n' in complexity:
            return complexity.count('log n') or 1
        return 0

    def _analyze_loops(self, func: FunctionInfo) -> tuple[str, str] | None:
        """Compute complexity from loop structure, including STL calls inside loops.

        Each *nesting chain* multiplies: the complexity is the product of every
        loop layer's linear/log contribution, times any STL calls inside bodies.
        Sequential (non-nested) chains take the max.
        """
        if not func.loops:
            return None

        # ── Build the nesting tree and compute per-chain complexity ──────
        # 1. Separate loops into independent "chains" based on nesting stack.
        #    Two loops at the same nesting level that don't overlap are sequential
        #    (max'd).  Two loops where one is inside the other are nested (×).

        sorted_loops = sorted(func.loops, key=lambda l: (l.body_start, -l.body_end))

        chains: list[list[LoopInfo]] = []  # each chain = root → leaf
        current_path: list[LoopInfo] = []  # stack of enclosing loops

        for loop in sorted_loops:
            # Pop from path until we find an enclosing loop (or empty)
            while current_path and current_path[-1].body_end <= loop.body_start:
                completed_chain = list(current_path)
                chains.append(completed_chain)
                current_path.pop()

            current_path.append(loop)

        # Flush remaining path
        if current_path:
            chains.append(list(current_path))
            # Also add sub-chains (prefixes)
            for i in range(1, len(current_path)):
                chains.append(current_path[:i])

        # Deduplicate chains
        unique_chains: list[tuple[LoopInfo, ...]] = []
        seen = set()
        for ch in chains:
            key = tuple(l.body_start for l in ch)
            if key not in seen:
                seen.add(key)
                unique_chains.append(tuple(ch))

        if not unique_chains:
            # Fallback: treat all loops individually
            unique_chains = [(l,) for l in sorted_loops]

        # 2. Compute complexity for each chain
        best_big_o = 'O(1)'
        best_rank = 0
        best_reason = ''
        best_chain: tuple[LoopInfo, ...] = ()

        for chain in unique_chains:
            linear_count = 0
            log_count = 0
            reason_parts = []

            for loop in chain:
                if loop.is_logarithmic:
                    log_count += 1
                    reason_parts.append(f'{loop.loop_type}[log]')
                else:
                    linear_count += 1
                    reason_parts.append(loop.loop_type)

                # STL calls inside THIS loop body
                for stl in func.stl_calls:
                    if loop.body_start <= stl.body_pos <= loop.body_end:
                        linear_count += self._stl_n_factor(stl.complexity)
                        log_count += self._stl_log_factor(stl.complexity)
                        reason_parts.append(f'{stl.name}({stl.complexity})')

            # Build Big-O from linear_count & log_count
            if linear_count == 0 and log_count == 0:
                big_o = 'O(1)'
            elif linear_count == 0:
                big_o = 'O(log n)' if log_count == 1 else f'O(log{self._superscript(log_count)} n)'
            elif log_count == 0:
                big_o = 'O(n)' if linear_count == 1 else f'O(n{self._superscript(linear_count)})'
            else:
                n_part = 'n' if linear_count == 1 else f'n{self._superscript(linear_count)}'
                log_part = 'log n' if log_count == 1 else f'log{self._superscript(log_count)} n'
                big_o = f'O({n_part} {log_part})'

            rank = self._RANK.get(big_o, 9)
            if rank > best_rank:
                best_rank = rank
                best_big_o = big_o
                best_reason = ' × '.join(reason_parts)
                best_chain = chain

        reason = (f'Dominant loop chain: {best_reason}'
                  if best_reason else 'Loop-based complexity')
        return (best_big_o, reason)

    # ── Recursion Analysis ──────────────────────────────────────────────────

    def _analyze_recursion(self, func: FunctionInfo) -> tuple[str, str] | None:
        """Compute complexity from recursion pattern (Master Theorem)."""
        if not func.recursion.is_recursive:
            return None

        r = func.recursion

        # Compute the non-recursive work complexity
        non_recursive_complexity = 'O(1)'
        if func.loops:
            loop_result = self._analyze_loops(func)
            if loop_result:
                non_recursive_complexity = loop_result[0]

        # Master Theorem cases:
        # T(n) = a * T(n/b) + f(n)

        a = r.branches  # number of recursive calls
        b = r.divisor   # input size divisor

        if r.recurrence_type in ('divide_by_2', 'divide') and b >= 2:
            if a == 1:
                # T(n) = T(n/2) + f(n) → O(f(n) * log n) or just O(log n) if f(n)=O(1)
                if non_recursive_complexity in ('O(1)', 'O(log n)'):
                    return ('O(log n)',
                            f'Single recursive call halving input: T(n)=T(n/{b})+O(1) → O(log n)')
                elif non_recursive_complexity == 'O(n)':
                    return ('O(n)',
                            f'T(n)=T(n/{b})+O(n) → O(n) (work dominates recursion)')
                else:
                    return (non_recursive_complexity,
                            f'T(n)=T(n/{b})+f(n) where f(n) dominates')

            elif a == 2:
                # T(n) = 2T(n/2) + f(n)
                # log_b(a) = log_2(2) = 1 → n^1 = n
                if non_recursive_complexity in ('O(n)',):
                    return ('O(n log n)',
                            f'Divide & conquer: T(n)=2T(n/{b})+O(n) → O(n log n) — Case 2 of Master Theorem')
                elif non_recursive_complexity in ('O(1)', 'O(log n)'):
                    return ('O(n)',
                            f'T(n)=2T(n/{b})+O(1) → O(n) — recursion dominates (Case 1)')
                else:
                    return ('O(n log n)',
                            f'Divide & conquer: T(n)=2T(n/{b})+f(n) → O(n log n)')

            elif a > 2:
                return ('O(2ⁿ)',
                        f'T(n)={a}T(n/{b})+f(n): many branches per call → exponential')

        elif r.recurrence_type == 'subtract_1':
            if a == 1:
                # T(n) = T(n-1) + f(n)
                if non_recursive_complexity in ('O(1)', 'O(log n)'):
                    return ('O(n)',
                            f'Linear recursion: T(n)=T(n-1)+O(1) called n times → O(n)')
                elif non_recursive_complexity == 'O(n)':
                    return ('O(n²)',
                            f'T(n)=T(n-1)+O(n) → O(n²)')
                else:
                    return ('O(n)',
                            f'Linear recursion: T(n)=T(n-1)+f(n) → O(n·f(n))')
            elif a >= 2:
                # T(n) = 2T(n-1) + O(1) → O(2ⁿ)  (e.g. Fibonacci, Tower of Hanoi)
                return ('O(2ⁿ)',
                        f'Branching recursion: T(n)={a}T(n-1)+O(1) → O({a}ⁿ) ≈ O(2ⁿ)')

        elif r.recurrence_type == 'branch' or (r.recurrence_type == 'single' and a >= 2):
            # Multiple recursive calls without halving → exponential
            if a == 2:
                return ('O(2ⁿ)',
                        f'Binary branching recursion (e.g., Fibonacci): T(n)=T(n-1)+T(n-2)+O(1) → O(2ⁿ)')
            else:
                return ('O(2ⁿ)',
                        f'Branching recursion with {a} calls per invocation → O({a}ⁿ)')

        elif r.recurrence_type == 'mutual':
            return ('O(n)',  # conservative default
                    'Mutual recursion detected — complexity approximated as O(n)')

        # Fallback for unknown recursion patterns
        if a == 1:
            return ('O(n)',
                    'Recursive function with unknown pattern — conservatively estimated as O(n)')
        else:
            return ('O(2ⁿ)',
                    f'Recursive function with {a} self-calls and unknown pattern → conservatively O(2ⁿ)')

    # ── STL Analysis ────────────────────────────────────────────────────────

    def _analyze_stl(self, func: FunctionInfo) -> list[tuple[str, str]]:
        """Generate complexity entries for STL calls."""
        results = []
        seen = set()
        for stl in func.stl_calls:
            if stl.name not in seen:
                seen.add(stl.name)
                results.append((stl.complexity,
                                f'Calls {stl.name} (complexity: {stl.complexity})'))
        return results

    # ── Combination Logic ───────────────────────────────────────────────────

    def _combine_complexities(self, complexities: list[tuple[str, str]]) -> tuple[str, str]:
        """Combine multiple complexity sources: sequential takes the max."""
        if len(complexities) == 1:
            return complexities[0]

        # Normalize and find the most complex
        max_idx = -1
        max_complexity = ('Unknown', '')
        reasons = []

        for comp, reason in complexities:
            reasons.append(f"• {reason}")
            idx = self._complexity_index.get(comp, len(self.COMPLEXITY_ORDER))
            if idx > max_idx:
                max_idx = idx
                max_complexity = (comp, reason)

        combined_reason = (
            f"Multiple factors detected (sequential → max complexity):\n" +
            '\n'.join(reasons) +
            f"\n\nDominant factor: {max_complexity[1]}"
        )
        return max_complexity[0], combined_reason

    def _superscript(self, n: int) -> str:
        """Convert a number to unicode superscript."""
        superscripts = str.maketrans('0123456789', '⁰¹²³⁴⁵⁶⁷⁸⁹')
        return str(n).translate(superscripts)

    def _determine_confidence(self, func: FunctionInfo,
                               complexities: list[tuple[str, str]]) -> Confidence:
        """Heuristic confidence rating based on what we found."""
        num_sources = len(complexities)

        # High confidence: clear single source with simple patterns
        if num_sources == 0:
            return Confidence.HIGH
        if num_sources == 1:
            if func.max_loop_depth <= 2 and not func.recursion.is_recursive:
                return Confidence.HIGH
            if func.recursion.recurrence_type in ('divide_by_2', 'subtract_1'):
                return Confidence.HIGH
            return Confidence.MEDIUM

        # Multiple interacting sources → lower confidence
        if func.recursion.is_recursive and func.loops:
            return Confidence.LOW
        if func.recursion.recurrence_type == 'unknown':
            return Confidence.LOW
        if func.recursion.is_mutual_recursive:
            return Confidence.LOW

        return Confidence.MEDIUM


# ═══════════════════════════════════════════════════════════════════════════════
# GUI Application
# ═══════════════════════════════════════════════════════════════════════════════

class ComplexityGUI:
    """tkinter-based GUI for the C++ Time Complexity Analyzer."""

    # C++ keywords for syntax highlighting
    CPP_KEYWORDS = {
        'alignas', 'alignof', 'and', 'and_eq', 'asm', 'auto', 'bitand', 'bitor',
        'bool', 'break', 'case', 'catch', 'char', 'char8_t', 'char16_t', 'char32_t',
        'class', 'compl', 'concept', 'const', 'consteval', 'constexpr', 'const_cast',
        'continue', 'co_await', 'co_return', 'co_yield', 'decltype', 'default',
        'delete', 'do', 'double', 'dynamic_cast', 'else', 'enum', 'explicit',
        'export', 'extern', 'false', 'float', 'for', 'friend', 'goto', 'if',
        'inline', 'int', 'long', 'mutable', 'namespace', 'new', 'noexcept',
        'not', 'not_eq', 'nullptr', 'operator', 'or', 'or_eq', 'override',
        'private', 'protected', 'public', 'register', 'reinterpret_cast',
        'requires', 'return', 'short', 'signed', 'sizeof', 'static',
        'static_assert', 'static_cast', 'struct', 'switch', 'template', 'this',
        'thread_local', 'throw', 'true', 'try', 'typedef', 'typeid', 'typename',
        'union', 'unsigned', 'using', 'virtual', 'void', 'volatile', 'wchar_t',
        'while', 'xor', 'xor_eq',
    }

    CPP_TYPES = {
        'int', 'long', 'short', 'char', 'float', 'double', 'bool', 'void',
        'unsigned', 'signed', 'auto', 'size_t', 'string', 'vector', 'map',
        'set', 'list', 'deque', 'queue', 'stack', 'array', 'pair', 'tuple',
        'unordered_map', 'unordered_set', 'priority_queue', 'unique_ptr',
        'shared_ptr', 'weak_ptr', 'string_view', 'span', 'optional',
    }

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("C++ Time Complexity Analyzer")
        self.root.geometry("1200x750")
        self.root.minsize(900, 500)

        # State
        self._current_file: str | None = None
        self._analysis_results: list[ComplexityResult] = []
        self._functions: list[FunctionInfo] = []

        # Style
        self._setup_style()
        # Build UI
        self._build_ui()

    def run(self):
        """Start the GUI main loop."""
        self.root.mainloop()

    # ── Style ────────────────────────────────────────────────────────────────

    def _setup_style(self):
        """Configure ttk styles."""
        style = ttk.Style()
        # Use a theme that looks good cross-platform
        available = style.theme_names()
        if 'clam' in available:
            style.theme_use('clam')

        style.configure('Title.TLabel', font=('Segoe UI', 11, 'bold'))
        style.configure('StatusBar.TLabel', font=('Segoe UI', 9),
                        padding=(10, 4), background='#e0e0e0')
        style.configure('Toolbar.TButton', padding=(10, 4))
        style.configure('Toolbar.TFrame', padding=(8, 6))

    # ── UI Construction ─────────────────────────────────────────────────────

    def _build_ui(self):
        """Construct the entire GUI layout."""
        # ── Top Toolbar ──
        toolbar = ttk.Frame(self.root, style='Toolbar.TFrame')
        toolbar.pack(fill=tk.X, padx=4, pady=(4, 0))

        ttk.Label(toolbar, text="File:", font=('Segoe UI', 10)).pack(side=tk.LEFT, padx=(0, 6))

        self._file_var = tk.StringVar()
        file_entry = ttk.Entry(toolbar, textvariable=self._file_var, state='readonly', width=60)
        file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))

        browse_btn = ttk.Button(toolbar, text="Browse...", style='Toolbar.TButton',
                                command=self._on_browse)
        browse_btn.pack(side=tk.LEFT, padx=(0, 4))

        self._analyze_btn = ttk.Button(toolbar, text="▶ Analyze", style='Toolbar.TButton',
                                       command=self._on_analyze)
        self._analyze_btn.pack(side=tk.LEFT, padx=(0, 4))

        clear_btn = ttk.Button(toolbar, text="Clear", style='Toolbar.TButton',
                               command=self._on_clear)
        clear_btn.pack(side=tk.LEFT)

        # ── Main Content: PanedWindow ──
        paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Left panel: Source code
        code_frame = ttk.Frame(paned)
        paned.add(code_frame, weight=5)

        code_header = ttk.Frame(code_frame)
        code_header.pack(fill=tk.X)
        ttk.Label(code_header, text="Source Code", style='Title.TLabel').pack(
            side=tk.LEFT, padx=8, pady=(6, 2))
        ttk.Label(code_header, text="(Line numbers shown)",
                  font=('Segoe UI', 8), foreground='gray').pack(
            side=tk.LEFT, padx=(4, 0), pady=(6, 2))

        # Inner frame for code + line numbers + scrollbars
        code_inner = ttk.Frame(code_frame)
        code_inner.pack(fill=tk.BOTH, expand=True)

        # Line number gutter
        self._lineno_text = tk.Text(code_inner, width=5, font=('Consolas', 11),
                                     bg='#252526', fg='#858585',
                                     relief=tk.FLAT, borderwidth=0,
                                     padx=6, pady=8, state=tk.DISABLED,
                                     wrap=tk.NONE)
        self._lineno_text.pack(side=tk.LEFT, fill=tk.Y)

        # Vertical scrollbar
        code_v_scroll = ttk.Scrollbar(code_inner, orient=tk.VERTICAL)
        code_v_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Horizontal scrollbar
        code_h_scroll = ttk.Scrollbar(code_inner, orient=tk.HORIZONTAL)
        code_h_scroll.pack(side=tk.BOTTOM, fill=tk.X)

        # Main code text
        self._code_text = tk.Text(code_inner, wrap=tk.NONE, font=('Consolas', 11),
                                  bg='#1e1e1e', fg='#d4d4d4',
                                  insertbackground='white',
                                  selectbackground='#264f78',
                                  relief=tk.FLAT, borderwidth=0,
                                  padx=10, pady=8,
                                  yscrollcommand=code_v_scroll.set,
                                  xscrollcommand=code_h_scroll.set)
        self._code_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        code_v_scroll.configure(command=self._on_code_scroll_y)
        code_h_scroll.configure(command=self._code_text.xview)

        # Configure code text tags for syntax highlighting
        self._setup_code_tags()

        # Right panel: Results
        results_frame = ttk.Frame(paned)
        paned.add(results_frame, weight=4)

        ttk.Label(results_frame, text="Analysis Results", style='Title.TLabel').pack(
            anchor=tk.W, padx=8, pady=(6, 2))

        # Treeview for results table
        tree_container = ttk.Frame(results_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=4)

        columns = ('function', 'big_o', 'confidence')
        self._tree = ttk.Treeview(tree_container, columns=columns, show='headings',
                                  selectmode='browse', height=10)

        self._tree.heading('function', text='Function', anchor=tk.W)
        self._tree.heading('big_o', text='Big-O Complexity', anchor=tk.W)
        self._tree.heading('confidence', text='Confidence', anchor=tk.CENTER)

        self._tree.column('function', width=180, minwidth=120)
        self._tree.column('big_o', width=140, minwidth=100, anchor=tk.CENTER)
        self._tree.column('confidence', width=90, minwidth=70, anchor=tk.CENTER)

        tree_v_scroll = ttk.Scrollbar(tree_container, orient=tk.VERTICAL,
                                      command=self._tree.yview)
        self._tree.configure(yscrollcommand=tree_v_scroll.set)

        self._tree.grid(row=0, column=0, sticky='nsew')
        tree_v_scroll.grid(row=0, column=1, sticky='ns')
        tree_container.grid_rowconfigure(0, weight=1)
        tree_container.grid_columnconfigure(0, weight=1)

        # Bind selection
        self._tree.bind('<<TreeviewSelect>>', self._on_result_select)

        # Detail panel
        detail_label = ttk.Label(results_frame, text="Details:",
                                 font=('Segoe UI', 10, 'bold'))
        detail_label.pack(anchor=tk.W, padx=8, pady=(8, 2))

        self._detail_text = tk.Text(results_frame, wrap=tk.WORD, height=10,
                                    font=('Segoe UI', 10), state=tk.DISABLED,
                                    relief=tk.SUNKEN, borderwidth=1,
                                    padx=10, pady=8)
        self._detail_text.pack(fill=tk.BOTH, expand=True, padx=4, pady=(0, 4))

        # Configure detail text tags
        self._detail_text.tag_configure('big_o', font=('Segoe UI', 13, 'bold'),
                                        foreground='#0066cc')
        self._detail_text.tag_configure('reason', font=('Segoe UI', 10),
                                        foreground='#333333')
        self._detail_text.tag_configure('high', foreground='#228B22')
        self._detail_text.tag_configure('medium', foreground='#DAA520')
        self._detail_text.tag_configure('low', foreground='#CD5C5C')

        # ── Status Bar ──
        status_frame = ttk.Frame(self.root)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)

        self._status_var = tk.StringVar(value="Ready. Open a .cpp file to begin.")
        status_bar = ttk.Label(status_frame, textvariable=self._status_var,
                               style='StatusBar.TLabel', anchor=tk.W)
        status_bar.pack(fill=tk.X)

    def _setup_code_tags(self):
        """Configure syntax highlighting tags for code display."""
        self._code_text.tag_configure('keyword', foreground='#569CD6')
        self._code_text.tag_configure('type', foreground='#4EC9B0')
        self._code_text.tag_configure('comment', foreground='#6A9955')
        self._code_text.tag_configure('string', foreground='#CE9178')
        self._code_text.tag_configure('number', foreground='#B5CEA8')
        self._code_text.tag_configure('preprocessor', foreground='#9B9B9B')
        self._code_text.tag_configure('function_name', foreground='#DCDCAA')

    # ── Scrolling Sync ──────────────────────────────────────────────────────

    def _on_code_scroll_y(self, *args):
        """Sync vertical scrolling: code text drives line numbers."""
        self._code_text.yview(*args)
        self._sync_lineno_view()

    def _sync_lineno_view(self):
        """Keep line numbers scrolled to same position as code text."""
        first = self._code_text.yview()[0]
        self._lineno_text.yview_moveto(first)

    # ── Events ──────────────────────────────────────────────────────────────

    def _on_browse(self):
        """Open file dialog to select a .cpp file."""
        filepath = filedialog.askopenfilename(
            title="Select C++ Source File",
            filetypes=[
                ("C++ Files", "*.cpp *.cc *.cxx *.h *.hpp *.hxx"),
                ("C Files", "*.c"),
                ("All Files", "*.*"),
            ],
        )
        if filepath:
            self._current_file = filepath
            self._file_var.set(filepath)
            self._load_file(filepath)

    def _on_analyze(self):
        """Analyze the currently loaded file."""
        if not self._current_file:
            messagebox.showwarning("No File", "Please open a .cpp file first.")
            return
        self._run_analysis()

    def _on_clear(self):
        """Clear all results and loaded file."""
        self._current_file = None
        self._file_var.set('')
        self._code_text.delete('1.0', tk.END)
        self._lineno_text.configure(state=tk.NORMAL)
        self._lineno_text.delete('1.0', tk.END)
        self._lineno_text.configure(state=tk.DISABLED)
        self._tree.delete(*self._tree.get_children())
        self._detail_text.configure(state=tk.NORMAL)
        self._detail_text.delete('1.0', tk.END)
        self._detail_text.configure(state=tk.DISABLED)
        self._analysis_results = []
        self._functions = []
        self._status_var.set("Ready. Open a .cpp file to begin.")

    def _on_result_select(self, event):
        """Show detail when a result row is selected."""
        selection = self._tree.selection()
        if not selection:
            return

        idx = int(self._tree.index(selection[0]))
        if 0 <= idx < len(self._analysis_results):
            result = self._analysis_results[idx]
            self._show_detail(result)

    # ── Core Logic ──────────────────────────────────────────────────────────

    def _load_file(self, filepath: str):
        """Load and display a C++ source file."""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("Error", f"Could not read file:\n{e}")
            return

        self._code_text.delete('1.0', tk.END)
        self._code_text.insert('1.0', content)

        # Apply syntax highlighting
        self._highlight_syntax(content)

        # Update line numbers
        self._update_line_numbers(content)

        # Update status
        self._status_var.set(f"Loaded: {os.path.basename(filepath)} ({len(content.splitlines())} lines) — Click 'Analyze' to begin.")

    def _update_line_numbers(self, content: str):
        """Update the line number gutter."""
        lines = content.split('\n')
        line_count = len(lines)
        line_numbers = '\n'.join(str(i + 1) for i in range(line_count))

        self._lineno_text.configure(state=tk.NORMAL)
        self._lineno_text.delete('1.0', tk.END)
        self._lineno_text.insert('1.0', line_numbers)
        self._lineno_text.configure(state=tk.DISABLED)

    def _highlight_syntax(self, content: str):
        """Apply simple syntax highlighting to the code display."""
        # Remove all existing tags first
        for tag in ('keyword', 'type', 'comment', 'string', 'number',
                     'preprocessor', 'function_name'):
            self._code_text.tag_remove(tag, '1.0', tk.END)

        # Comments (// ...)
        for match in re.finditer(r'//[^\n]*', content):
            start = f'1.0 + {match.start()} chars'
            end = f'1.0 + {match.end()} chars'
            self._code_text.tag_add('comment', start, end)

        # Strings
        for match in re.finditer(r'"(?:\\.|[^"\\])*"', content):
            start = f'1.0 + {match.start()} chars'
            end = f'1.0 + {match.end()} chars'
            self._code_text.tag_add('string', start, end)

        # Preprocessor
        for match in re.finditer(r'^\s*#.*$', content, re.MULTILINE):
            start = f'1.0 + {match.start()} chars'
            end = f'1.0 + {match.end()} chars'
            self._code_text.tag_add('preprocessor', start, end)

        # Numbers
        for match in re.finditer(r'\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b', content):
            start = f'1.0 + {match.start()} chars'
            end = f'1.0 + {match.end()} chars'
            self._code_text.tag_add('number', start, end)

        # Keywords
        for keyword in self.CPP_KEYWORDS:
            for match in re.finditer(r'\b' + re.escape(keyword) + r'\b', content):
                start = f'1.0 + {match.start()} chars'
                end = f'1.0 + {match.end()} chars'
                self._code_text.tag_add('keyword', start, end)

        # Types (after keywords so types take precedence)
        for ctype in self.CPP_TYPES:
            for match in re.finditer(r'\b' + re.escape(ctype) + r'\b', content):
                start = f'1.0 + {match.start()} chars'
                end = f'1.0 + {match.end()} chars'
                self._code_text.tag_add('type', start, end)

    def _run_analysis(self):
        """Parse the file and run complexity analysis."""
        if not self._current_file:
            return

        with open(self._current_file, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()

        # Parse
        parser = CppParser()
        self._functions = parser.parse(content)

        # Analyze
        analyzer = ComplexityAnalyzer()
        self._analysis_results = [analyzer.analyze(func) for func in self._functions]

        # Update tree
        self._tree.delete(*self._tree.get_children())
        for i, result in enumerate(self._analysis_results):
            conf_str = result.confidence.value
            self._tree.insert('', tk.END, iid=str(i),
                              values=(result.function_name, result.big_o, conf_str))

        # Update status
        func_count = len(self._analysis_results)
        self._status_var.set(
            f"Analysis complete: {func_count} function{'s' if func_count != 1 else ''} analyzed. "
            f"File: {os.path.basename(self._current_file)}"
        )

        # Auto-select first result
        if self._analysis_results:
            self._tree.selection_set('0')
            self._show_detail(self._analysis_results[0])

    def _show_detail(self, result: ComplexityResult):
        """Display detailed reasoning for a result."""
        self._detail_text.configure(state=tk.NORMAL)
        self._detail_text.delete('1.0', tk.END)

        # Function name and complexity
        self._detail_text.insert(tk.END, f"Function: ", 'reason')
        self._detail_text.insert(tk.END, f"{result.function_name}\n\n", 'function_name')

        self._detail_text.insert(tk.END, f"Time Complexity: ", 'reason')
        self._detail_text.insert(tk.END, f"{result.big_o}\n\n", 'big_o')

        self._detail_text.insert(tk.END, f"Confidence: ", 'reason')
        conf_tag = result.confidence.name.lower()
        self._detail_text.insert(tk.END, f"{result.confidence.value}\n\n", conf_tag)

        self._detail_text.insert(tk.END, f"Analysis:\n", 'reason')
        self._detail_text.insert(tk.END, f"{result.reasoning}\n", 'reason')

        # If we have the original function, show additional info
        for func in self._functions:
            if func.name == result.function_name:
                if func.loops:
                    self._detail_text.insert(tk.END, f"\nLoops detected: {len(func.loops)}\n", 'reason')
                    for loop in func.loops:
                        log_note = " (logarithmic)" if loop.is_logarithmic else ""
                        self._detail_text.insert(tk.END,
                            f"  • {loop.loop_type} at nesting level {loop.nesting_level}{log_note}\n",
                            'reason')
                if func.stl_calls:
                    self._detail_text.insert(tk.END, f"\nSTL calls:\n", 'reason')
                    for stl in func.stl_calls:
                        self._detail_text.insert(tk.END,
                            f"  • {stl.name} → {stl.complexity}\n", 'reason')
                if func.recursion.is_recursive:
                    r = func.recursion
                    self._detail_text.insert(tk.END, f"\nRecursion detected:\n", 'reason')
                    self._detail_text.insert(tk.END, f"  • Pattern: {r.recurrence_type}\n", 'reason')
                    self._detail_text.insert(tk.END, f"  • Branches: {r.branches}\n", 'reason')
                    if r.divisor > 1:
                        self._detail_text.insert(tk.END, f"  • Input divisor: {r.divisor}\n", 'reason')
                break

        self._detail_text.configure(state=tk.DISABLED)


# ═══════════════════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    app = ComplexityGUI()
    app.run()


if __name__ == '__main__':
    main()
