// Mixed complexity: STL algorithms and loop interactions

#include <vector>
#include <algorithm>
#include <set>

// O(n log n) - sort dominates over the subsequent linear loop
void sortThenIterate(std::vector<int>& arr) {
    std::sort(arr.begin(), arr.end());  // O(n log n)
    for (size_t i = 0; i < arr.size(); i++) {  // O(n)
        arr[i] *= 2;
    }
    // Sequential: max(O(n log n), O(n)) = O(n log n)
}

// O(n log n) - Loop containing binary_search
// Loop: O(n), each iteration O(log n) → O(n log n)
void loopWithBinarySearch(const std::vector<int>& sorted, const std::vector<int>& queries) {
    for (int q : queries) {  // O(m)
        std::binary_search(sorted.begin(), sorted.end(), q);  // O(log n)
    }
}

// O(n² log n) - Nested loops + sort inside inner loop
void nestedWithSort(std::vector<std::vector<int>>& matrix) {
    for (auto& row : matrix) {  // O(rows)
        std::sort(row.begin(), row.end());  // O(cols log cols)
    }
}

// O(n) - Simple STL: find, count, reverse
void simpleSTL(std::vector<int>& arr, int target) {
    auto it = std::find(arr.begin(), arr.end(), target);  // O(n)
    int cnt = std::count(arr.begin(), arr.end(), target);  // O(n)
    std::reverse(arr.begin(), arr.end());                  // O(n)
}

// O(log n) - STL heap operations
void heapOperations(std::vector<int>& heap, int val) {
    std::push_heap(heap.begin(), heap.end());   // O(log n)
    std::pop_heap(heap.begin(), heap.end());    // O(log n)
}
