// O(n²) - Quadratic time complexity
// Nested loops

#include <vector>
#include <algorithm>

// O(n²) - Two nested linear loops
void bubbleSort(std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                std::swap(arr[j], arr[j + 1]);
            }
        }
    }
}

// O(n²) - Two nested loops with independent bounds
void printAllPairs(const std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            // O(n²): printing all pairs
            printf("%d %d\n", arr[i], arr[j]);
        }
    }
}

// O(n³) - Three nested loops
void tripleLoop(const std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                // O(n³)
                printf("%d\n", arr[i] + arr[j] + arr[k]);
            }
        }
    }
}
