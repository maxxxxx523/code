// O(2ⁿ) - Exponential (Naive Fibonacci)
// T(n) = T(n-1) + T(n-2) + O(1)

// O(2ⁿ) - Naive recursive Fibonacci
long long fibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

// O(n) - Linear recursion (factorial-style)
// T(n) = T(n-1) + O(1)
long long factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

// O(2ⁿ) - Tower of Hanoi-style branching
void towerOfHanoi(int n, char from, char to, char aux) {
    if (n == 1) {
        printf("Move disk 1 from %c to %c\n", from, to);
        return;
    }
    towerOfHanoi(n - 1, from, aux, to);
    printf("Move disk %d from %c to %c\n", n, from, to);
    towerOfHanoi(n - 1, aux, to, from);
}

// O(1) - No loops, no recursion
int addConstant(int x) {
    return x + 42;
}
