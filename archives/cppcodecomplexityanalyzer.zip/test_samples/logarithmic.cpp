// O(log n) - Logarithmic time complexity
// Binary search and other divide-by-2 algorithms

#include <vector>

// O(log n) - Classic binary search
int binarySearch(const std::vector<int>& arr, int target) {
    int left = 0;
    int right = arr.size() - 1;

    while (left <= right) {
        int mid = (left + right) / 2;

        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}

// O(log n) - Loop counter multiplies by 2
void logarithmicLoop(int n) {
    for (int i = 1; i < n; i *= 2) {
        // i grows: 1, 2, 4, 8, 16, ..., n
        // Number of iterations: log₂(n)
        printf("%d\n", i);
    }
}

// O(log n) - Loop counter divides by 2
void descendingLog(int n) {
    for (int i = n; i > 1; i /= 2) {
        printf("%d\n", i);
    }
}

// O(log n) - Exponentiation by squaring
long long fastPow(long long base, long long exp, long long mod) {
    long long result = 1;
    base = base % mod;

    while (exp > 0) {
        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exp /= 2;
    }
    return result;
}
