// O(n log n) - Divide and Conquer (Merge Sort)
// T(n) = 2T(n/2) + O(n)

#include <vector>
#include <algorithm>

void merge(std::vector<int>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    std::vector<int> L(n1), R(n2);
    for (int i = 0; i < n1; i++) L[i] = arr[left + i];
    for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

// O(n log n) - Divide and conquer recursion
void mergeSort(std::vector<int>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);      // T(n/2)
        mergeSort(arr, mid + 1, right); // T(n/2)
        merge(arr, left, mid, right);   // O(n)
    }
}

// O(n log n) - sort within loop (but not nested)
void sortMultiple(std::vector<std::vector<int>>& matrix) {
    // O(rows * cols log cols)
    for (size_t i = 0; i < matrix.size(); i++) {
        std::sort(matrix[i].begin(), matrix[i].end());
    }
}
