// O(n) - Linear time complexity
// Single loop iterating through an array

#include <vector>

int sumArray(const std::vector<int>& arr) {
    int sum = 0;
    for (size_t i = 0; i < arr.size(); i++) {
        sum += arr[i];
    }
    return sum;
}

int findMax(const std::vector<int>& arr) {
    int max_val = arr[0];
    for (size_t i = 1; i < arr.size(); ++i) {
        if (arr[i] > max_val) {
            max_val = arr[i];
        }
    }
    return max_val;
}

// Should also be O(n) - sequential loops, not nested
void doublePass(std::vector<int>& arr) {
    // First pass: O(n)
    for (size_t i = 0; i < arr.size(); i++) {
        arr[i] *= 2;
    }
    // Second pass: O(n)
    for (size_t i = 0; i < arr.size(); i++) {
        arr[i] += 1;
    }
    // Sequential is max(O(n), O(n)) = O(n)
}
